<!DOCTYPE html>
<html>
<head>
    <title>Taruntests.com</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body1'] }}</p>
    <p>{{ $details['body2'] }}</p>
    <p>{{ $details['body3'] }}</p>
    <p>{{ $details['body4'] }}</p>
    <p>{{ $details['body5'] }}</p>
    <p>{{ $details['body6'] }}</p>
    <p>{{ $details['body7']}}</p>



    <p>Thank you</p>
</body>
</html>
