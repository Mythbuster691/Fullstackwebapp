@extends('pages.main')
@section('content')
<div class="container py-3">
   <p > There must be a better way. This thought launched Damahir Travels Pvt Ltd 48 years ago and spurs our innovation today.
Find inspiration and information to help you book more travel to the all over word ! Browse robust regional and themed itineraries, beginning in key gateway cities and exploring beyond them to discover both iconic landmarks and hidden gems.
With great fun and exciting travel , and find out how to embed them in your own collateral. Learn important travel tips to help ensure that trips go smoothly, from visa and entry policy information to how to get around after arriving in your destination. Review resources customized to the travel trade including the latest on events, destination contacts and more.</p>

In 1970, <strong> DAMAHIR Travels Pvt Ltd </strong> was incorporated with the aim to provide world-class travel experience to the world. With decades of hard work and adherence to ethics and integrity, DAMAHIR Travels Pvt Ltd  has emerged as one of the leading Travel Organizations in USA. Spearheaded by Mr. Jackie Michael, today the company is based at more than 40 locations across USA, Canada, Dubai, Australia & GCC with a turnover of nearly Rs.11000 Crores and employing more than 1950 professionals. We have created a niche in travel market that has given us significant standing among our suppliers & clients.
We reckon travelling as an experience in itself hence should be easy and hassle free and so we provide end to end travel services. We are your one stop solution for all your travel requirements like air tickets, visa, travel insurance, forex and car rentals. We offer customized services as per your need like airport assistance, self booking tools and many such automated travel solutions. We constantly strive to make travelling a one-of-a-kind experience for you and our completely automated travel solutions are just the thing you need.
The turnaround time and deadlines are critical while dealing with travellers. Delivering the perfect solution to the ever changing needs of our clients is our ultimate goal. Our glorious number of clients and their testimonies can testify to that.




</div>
@endsection
