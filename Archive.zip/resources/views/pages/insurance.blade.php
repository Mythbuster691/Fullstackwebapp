@extends('pages.main')
@section('content')
<div class="container py-3">
    <p>Travel insurances <strong> is insurance </strong> that is intended to cover medical expenses, trip cancellation,lost luggage, flight accident and other losses incurred while traveling,
Travel insurance can usually be arranged at the time of the booking of a trip to cover exactly the duration of that trip, or a "multi-trip" policy can cover an unlimited number of trips within a set time frame. Some policies offer lower and higher medical-expense options; the higher ones are chiefly for countries that have high medical costs, such as the United States.
Some credit card issuers offer automatic travel insurance if travel arrangements are paid for using their credit cards, but these policies are generic and particular care must be taken to take into account personal requirements. There are many travel insurance policies available in the market place, but care must be taken of what events are covered by each policy, and what exclusions, exceptions and limits apply, besides other issues
</p>


</div>
@endsection
