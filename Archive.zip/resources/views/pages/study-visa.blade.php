@extends('pages.main')
@section('content')
<div class="container py-3">
    <h1>ABOUT STUDY VISA</h1><br>
    <p>Our mission is to help our clients achieve their aim of settling and completing higher studies from countries
        like USA , UK , Canada , New Zealand and Australia .</p><br>
    <p>Decision making can be one of the most difficult things to do in life. At DAMAHIR education consultants, even the
        most important decisions are made easier for you.</p><br>
    <p>At DAMAHIR Visa consultants, we take utmost care of your future plans and provide the right guidance and help you
        throughout the immigration process. Our credibility is what we offer. We provide value services so that you get
        the value of your money. After all those long years of hard work for a justify future its our chance to strive
        towards helping you fulfilling your ambitions.</p><br>
    <p>All you need to do now is come to us so that we can serve you by providing the best counseling and guidance to
        help you choose a dream career.</p><br>
    <p>DAMAHIR Visa Education Consultants is a path towards your dream destination. We endeavor to shape your future
        abroad. With us you are in safe hands, as we take care of everything from application, admission to visa. You
        just need to follow your dreams.</p><br>
    <p> Our services are considered the best in immigration industry to keep the tag of being an ethical and genuine
        company providing professional services to the satisfaction of our committed customers. our highly skilled,
        trained, qualified and experienced staff makes the visit memorable and the confidence is instilled in students
        who wish to pursue higher education abroad.</p><br>
    <p>At DAMAHIR Visa Consultants, unbiased approach towards any university makes the free counseling sessions more
        valuable and the student can head for a justify, prosperous future.</p><br>
    <p> Our core competence is visa documentation and expertise in Study Visa. We process the highest number of
        education cases. These thousands of case studies have given us the experience and expertise to handle any type
        of case.</p><br>
    <p>What our clients are comfortable with is the trust of our brand and the transparency of our process which is
        backed by a proper legal agreement. We hold your information which you submit to us in great trust.</p><br>
    <p>Whether you are a consumer client looking for an overseas career; a corporate or a university - talk to DAMAHIR
        Visa. You are talking to the countries best.</p><br>












</div>
@endsection
