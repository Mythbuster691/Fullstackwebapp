@extends('pages.main')
@section('content')
<div class="container py-3">
    <h1>We are Coming with Multiple Branches in World.</h1><br>
<h1>We required you to  apply soon</h1><br>
<h1>It’s not in current use by others</h1><br>
</div>
@endsection

