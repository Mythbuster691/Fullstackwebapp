<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="row py-3 ">
<div class="col-sm-5 align-self-center"><hr></div>
<div class="col-sm-2"> <button class="btn">
    <a class="btn btn-success mx-auto" href="<?php echo e(route('file-export')); ?>">Export data</a>
     </button></div>
<div class="col-sm-5 align-self-center"><hr></div>


        </div>
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="col">ID</th>
                        <th scope="col">Booking_id</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Contact</th>
                        <th scope="col">Slotdate</th>
                        <th scope="col">Slottime</th>
                        <th scope="col">center</th>
                        <th scope="col">Paymentstatus</th>
                        

                    </tr>
                </thead>
                <tbody>


                    <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <th scope="row"><?php echo e($career->id); ?></th>
                        <td> <?php echo e($career->booking_id); ?> </td>
                        <td> <?php echo e($career->name); ?> </td>
                        <td> <?php echo e($career->email); ?> </td>
                        <td> <?php echo e($career->contact_no); ?> </td>
                        <td scope="row"> <?php echo e($career->slotdate); ?> </td>
                        <td scope="row"> <?php echo e($career->slottiming); ?> </td>
                        <td scope="row"> <?php echo e($career->interview_destination); ?> </td>
                        <td scope="row">
                            <?php switch($career->paymentstatus ):
                            case (0): ?>
                                <a  class="btn btn-danger">Pending</a>
                            <?php break; ?>
                            <?php case (1): ?>
                                <a class="btn btn-success">Successful</a>
                            <?php break; ?>
                            <?php default: ?>

                            <?php endswitch; ?>

                        </td>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <span>
                    <?php echo e($careers->links()); ?>

                </span>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<style>
    .w-5 {
        display: none;
    }

</style>

<?php echo $__env->make('auth.dashboard.admindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/bhatiatravel/resources/views/auth/dashboard/home.blade.php ENDPATH**/ ?>