<div class="container-fluid ceo_bg">
    <div class="container " style="zoom: 1;">
        <div class="container-fluid" style="padding: 100px 8px 100px 8px;">
            <div class="from_desk_ceo row align-self-center">
                    <p>
                        <b>From the desk of CEO</b>
                        <span>Dear Respected Partner,</span>
                        <br>
                        First of all, I'd like to say a massive thank you for the continued support you offer to TBO. With your
                        help, the business continues to grow in all product sectors, and I am sure that you have experienced a
                        fruitful and profitable season too. <a href="">Read more...</a>
                    </p>

            </div>
        </div>
    </div>
</div>

<style>
    .ceo_bg {
    background: #91b4cf url('https://images.unsplash.com/photo-1462642109801-4ac2971a3a51?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDIwfHx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=800&q=60');
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}
.from_desk_ceo {
    background-color: #A97E50;
    opacity: .8;
    padding: 25px;
    border-radius: 10px;
    border: 3px dashed rgb(215, 215, 215);
    background: rgba(255, 255, 255,.9);
    box-shadow: 1.871px 8.803px 21px 0px rgba(0, 0, 0, 0.18);
}
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/bhatiatravel/resources/views/layouts/ceodesk.blade.php ENDPATH**/ ?>