<!DOCTYPE html>
<html>
<head>
    <title>Taruntests.com</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body1']); ?></p>
    <p><?php echo e($details['body2']); ?></p>
    <p><?php echo e($details['body3']); ?></p>
    <p><?php echo e($details['body4']); ?></p>
    <p><?php echo e($details['body5']); ?></p>
    <p><?php echo e($details['body6']); ?></p>
    <p><?php echo e($details['body7']); ?></p>



    <p>Thank you</p>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/bhatiatravel/resources/views/emails/myTestMail.blade.php ENDPATH**/ ?>