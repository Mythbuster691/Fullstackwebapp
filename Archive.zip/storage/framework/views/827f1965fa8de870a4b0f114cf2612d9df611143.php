<div class="container-fluid h-75">
    <img src="<?php echo e(asset('WhatsApp Image 2022-04-30 at 5.38.16 PM.jpeg')); ?>"  class="w-100" alt="">
</div>
<style>

</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/bhatiatravel/resources/views/layouts/footerimage.blade.php ENDPATH**/ ?>