<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <h1>We are Coming with Multiple Branches in World.</h1><br>
<h1>We required you to  apply soon</h1><br>
<h1>It’s not in current use by others</h1><br>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('pages.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/bhatiatravel/resources/views/pages/taglines.blade.php ENDPATH**/ ?>