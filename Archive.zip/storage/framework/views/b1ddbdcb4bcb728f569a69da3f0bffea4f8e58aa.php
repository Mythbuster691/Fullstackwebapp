<div class="container-fluid ceo_bg">
    <div class="container " style="zoom: 1;">
        <div class="container-fluid" style="padding: 100px 8px 100px 8px;">
            <div class="from_desk_ceo row align-self-center">
                    <p>
                        <b>From the desk of CEO</b>
                        <span>Dear Respected Partner,</span>
                        <br>
                        First of all, I'd like to say a massive thank you for the continued support you offer to TBO. With your
                        help, the business continues to grow in all product sectors, and I am sure that you have experienced a
                        fruitful and profitable season too. <a href="">Read more...</a>
                    </p>

            </div>
        </div>
    </div>
</div>

<style>
    .ceo_bg {
    background: #91b4cf url('https://www.travelboutiqueonline.com/new-design/images/ceobg.jpg');
    background-repeat: no-repeat;
    background-position: center;
}
.from_desk_ceo {
    padding: 25px;
    border-radius: 10px;
    border: 3px dashed rgb(215, 215, 215);
    background: rgba(255, 255, 255,.9);
    box-shadow: 1.871px 8.803px 21px 0px rgba(0, 0, 0, 0.18);
}
</style>
<?php /**PATH /Users/apple/Desktop/htdocs/bhatiatravel/resources/views/layouts/ceodesk.blade.php ENDPATH**/ ?>